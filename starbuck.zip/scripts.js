
let circulo = document.querySelector(".circulo")
let img = document.querySelector(".starbucks");


function trocarcor(cor){
    circulo.style.background = cor
}

function trocaImagem(imagem){
    img.src = imagem
}
